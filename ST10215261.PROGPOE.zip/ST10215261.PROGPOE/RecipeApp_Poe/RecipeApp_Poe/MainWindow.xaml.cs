﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace RecipeApp
{
    public partial class MainWindow : Window
    {    
        // List to store ingredients
        private List<Ingredient> ingredients;

        // List to store recipe steps
        private List<string> recipesteps;
        private List<Recipehold> Recipes;

        public MainWindow()
        {
            InitializeComponent();

            // Initialize the ingredients list
            ingredients = new List<Ingredient>();

            // Initialize the steps list
            recipesteps = new List<string>();

        }

        // Method to handle adding a new ingredient
        private void IngredientButton(object sender, RoutedEventArgs e)
        {
            // Get the input values from textboxes
            string name = txtName.Text;
            string foodGroup = txtFoodGroup.Text;
            string quantityText = txtQuantity.Text;
            string unit = txtUnit.Text;
            string caloriesText = txtCalories.Text;


            // Try parsing calories and quantity as double
            if (double.TryParse(caloriesText, out double calories) && double.TryParse(quantityText, out double quantity))
            {

              // Create a new Ingredient object
              Ingredient ingredient = new Ingredient(name, calories, unit, quantity, foodGroup);
                
              // Check if the ingredient has high calories
                if (calories > 300)
                {
                    MessageBox.Show(" Warning : Over 300 Calories! ");
                }

                // Add the ingredient to the list
                ingredients.Add(ingredient);

                // Update the ListBox to show the list of ingredients
                lstIngredients.ItemsSource = ingredients;
                lstIngredients.DisplayMemberPath = "Name";


                // Clear the input fields
              IngredientClearField();

            }
            else
            {
                MessageBox.Show("Invalid input. Please enter a valid number.");
            }
        }

        // Other event handlers and methods
        // Method to handle scaling the recipe based on a given factor
        private void StepButton(object sender, RoutedEventArgs e)
        {
            string step = txtStep.Text;
            recipesteps.Add(step);

            lstSteps.ItemsSource = recipesteps;

        StepClearField();
        }

        private void DisplayRecipeButton(object sender, RoutedEventArgs e)
        {
            string recipeName = txtRecipeName.Text;
            string ingredientsInfo = string.Join(Environment.NewLine, lstIngredients.Items.Cast<Ingredient>().Select(i => i.ToString()));
            string stepsInfo = string.Join(Environment.NewLine, lstSteps.Items.Cast<string>());

            double totalCalories = ingredients.Sum(i => i.Calories);
            
            string recipeInfo =
            $"Recipe Name: {recipeName}" + Environment.NewLine + $"Ingredients: {ingredientsInfo}" + Environment.NewLine +$"Total Calories: {totalCalories}" + Environment.NewLine +$"Steps: {stepsInfo}";

            
            MessageBox.Show(recipeInfo, "Recipe Information");
        }

        //recipe button
        private void EnterRecipeButton(object sender, RoutedEventArgs e)
        {
            string recipeName = txtRecipeName.Text;



            RecipeClearField();
        }

        //scaling button
        private void ScalingButton(object sender, RoutedEventArgs e)
        {
            string scalingFactorText = txtScalingFactor.Text;

            if (double.TryParse(scalingFactorText, out double scalingFactor))
            {
                if (scalingFactor > 0)
                {
                    // Scale ingredient quantities and calories
                    foreach (Ingredient ingredient in ingredients)
                    {
                        ingredient.Quantity *= scalingFactor;
                        ingredient.Calories *= scalingFactor;
                    }

                    // Scale steps
                    for (int i = 0; i < recipesteps.Count; i++)
                    {
                        recipesteps[i] = $"{i + 1}. {recipesteps[i]}";
                    }

                    // Display the scaled recipe information
                    string recipeName = txtRecipeName.Text;
                    string ingredientsInfo = string.Join(Environment.NewLine, ingredients.Select(i => $"{i.Name}: {i.Quantity} {i.Unit}"));
                    string stepsInfo = string.Join(Environment.NewLine, recipesteps);

                    double totalCalories = ingredients.Sum(i => i.Calories);
                    
                    string recipeInfo =
                    $"Scaled Recipe Name: {recipeName}" + Environment.NewLine +$"Scaled Ingredients: {ingredientsInfo}" + Environment.NewLine +$"Scaled Total Calories: {totalCalories}" + Environment.NewLine +$"Scaled Steps: {stepsInfo}";

                    
                    MessageBox.Show(recipeInfo, "Scaled Recipe");
                }
                
            else
            {
            MessageBox.Show("Invalid Scaling Factor","Must be greater than 0");
            }
            
            }
            else
            {
                MessageBox.Show("Invalid Scaling Factor");
            }
        }

        private void FilterButton_Click(object sender, RoutedEventArgs e)
        {
            string filterIngredient = txtFilterIngredient.Text;

            if (!string.IsNullOrWhiteSpace(filterIngredient))
            {
                List<Recipehold> filteredRecipes = new List<Recipehold>();

                foreach (Recipehold recipe in Recipes)
                {
                    bool containsIngredient = recipe.Ingredients.Any(ingredient => ingredient.Name.Equals(filterIngredient, StringComparison.OrdinalIgnoreCase));

                    if (containsIngredient)
                    {
                        filteredRecipes.Add(recipe);
                    }
                }

                // Display the filtered recipes
                DisplayFilteredRecipes(filteredRecipes);
            }
            else
            {
                // If no ingredient is entered, display all recipes
                DisplayFilteredRecipes(Recipes);
            }
        }

        private void DisplayFilteredRecipes(List<Recipehold> filteredRecipes)
        {
            // Clear previous recipe display
            lstRecipes.ItemsSource = null;
            lstRecipes.Items.Clear();

            // Bind the filtered recipes to the ListBox
            lstRecipes.ItemsSource = filteredRecipes;
            lstRecipes.DisplayMemberPath = "RecipeName";
        }


        // Other event handlers and methods
        //reset recipe
        private void ResetQuantitiesButton(object sender, RoutedEventArgs e)
        {
            foreach (Ingredient ingredient in ingredients)
            {
                ingredient.Quantity = 0;
                ingredient.Calories = 0;
            }

            IngredientClearField();
            MessageBox.Show("Quantities reset successfully.", "Reset Quantities");
        }

        //clear ingredients
        private void IngredientClearField()
        {
            txtName.Text = "";
            txtFoodGroup.Text = "";
            txtQuantity.Text = "";
            txtUnit.Text = "";
            txtCalories.Text = "";

        }

        //clear steps
        private void StepClearField()
        {
            txtStep.Text = "";
        }

        private void RecipeClearField()
        {
            txtRecipeName.Text = "";
        }

        //clear recipe button
        private void ClearRecipeButton(object sender, RoutedEventArgs e)
        {
           
            lstIngredients.ItemsSource = null;
            lstIngredients.Items.Clear();

            lstSteps.ItemsSource = null;
            lstSteps.Items.Clear();

            RecipeClearField();
            ingredients.Clear();
            recipesteps.Clear();

            MessageBox.Show("Recipe cleared successfully.", "Clear Recipe");
        }

        //exit the recipe app
        private void ExitButton(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void lstRecipes_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}

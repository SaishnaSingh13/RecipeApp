﻿using System.Collections.Generic;

// Recipe class representing a complete recipe with its name, ingredients, and steps
public class Recipehold
{
    public override string ToString()
    {
        return RecipeName;
    }
    public string RecipeName { get; set; }

    // List to store ingredients
    public List<Ingredient> Ingredients { get; set; }

    // List to store steps
    public List<string> Steps { get; set; }

    public Recipehold(string recipeName, List<Ingredient> ingredients, List<string> steps)
    {
        RecipeName = recipeName;
        Ingredients = ingredients;
        Steps = steps;
    }


}

﻿using System.Collections.Generic;

// Ingredient class representing an ingredient with its properties such as name, calories, quantity
public class Ingredient
{
    private string foodGroup;

    public string Name { get; set; }
    public double Calories { get; set; }
    public string Unit { get; set; }
    public double Quantity { get; set; }

    // List of food groups for each ingredient
    public List<string> FoodGroups { get; set; } 

    public Ingredient(string name, double calories, string unit, double quantity, List<string> foodGroups)
    {
        Name = name;
        Calories = calories;
        Unit = unit;
        Quantity = quantity;
        FoodGroups = foodGroups;
    }

    public Ingredient(string name, double calories, string unit, double quantity, string foodGroup)
    {
        Name = name;
        Calories = calories;
        Unit = unit;
        Quantity = quantity;
        this.foodGroup = foodGroup;
    }

    public override string ToString()
    {
        return $"{Name}, {Calories} calories, {Quantity} {Unit}";
    }


}